# RFID_Excel
Arduino Code for the attendance system with Excel
https://youtu.be/bd96662Rftg
