

def rnfi_database():

    import mysql.connector
    import RPi.GPIO as gp
    from mfrc522 import SimpleMFRC522
    reader=SimpleMFRC522()
    g = False
    db=mysql.connector.connect (
        host="databasesih.cdj6dkht0ydp.us-east-1.rds.amazonaws.com",
        user="admin",
        passwd="admin123",
        database="attendance")

    cursor=db.cursor()
    print("place your tag:")
    temp,data=reader.read()
    name,rollno=list(data.split())
    sql="insert into student_rfid (name,roll_no) values (%s,%s)"
    val=(name,rollno)
    try:
        cursor.execute(sql,val)
        print("Look in camera for facial verification")
        g =  True
    except Error as e:
        print("You are not a registered member")
    db.commit()
    return g 