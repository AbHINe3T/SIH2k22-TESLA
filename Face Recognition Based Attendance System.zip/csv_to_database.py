import pandas as pd
import mysql.connector as msql
from mysql.connector import Error

def getID(data):
  print(data[0])
  try:
    conn = msql.connect(host='databasesih.cdj6dkht0ydp.us-east-1.rds.amazonaws.com', user='admin', password='admin123',database='attendance')
    if conn.is_connected():
        cursor = conn.cursor()
        sql = "INSERT into final_attendance (name,roll_no) select * from student_rfid where student_rfid.roll_no=(%s)"
        val = data[0]
        cursor.execute(sql,(val,))
        conn.commit()
  except Error as e:
    elist=str(e).split()
    if elist[2]=='Duplicate':
      print("bhai attendance lag chuki h")
