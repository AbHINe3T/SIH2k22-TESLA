
def rnfiw():

    import RPi.GPIO as GP
    from mfrc522 import SimpleMFRC522

    GP.setwarnings(False)

    reader = SimpleMFRC522()


    try :
        while True:
            print("Hold a tag near the reader")
            id,text=reader.read()
            print(id,text)
            
            text = input("New Data:")
            print("Now place your tag to write")
            reader.write(text)
            
    except KeyboardInterrupt:
        GP.cleanup()
        raise