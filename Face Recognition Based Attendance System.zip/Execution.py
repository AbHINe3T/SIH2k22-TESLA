
import rfidwrite
import databasewrite

while True:
    if databasewrite.rnfi_database():
        import main
        main.TrackImages()
